#!/bin/bash
#############################################################
#   _______     _______ _               ____
#  / ____\ \   / / ____| |        /\   |  _ \
# | (___  \ \_/ / (___ | |       /  \  | |_) |
#  \___ \  \   / \___ \| |      / /\ \ |  _ <
#  ____) |  | |  ____) | |____ / ____ \| |_) |
# |_____/   |_| |_____/|______/_/    \_\____/


#   _____ _    _ _____  _____  ______ __  __ ______
#  / ____| |  | |  __ \|  __ \|  ____|  \/  |  ____|
# | (___ | |  | | |__) | |__) | |__  | \  / | |__
#  \___ \| |  | |  ___/|  _  /|  __| | |\/| |  __|
#  ____) | |__| | |    | | \ \| |____| |  | | |____
# |_____/ \____/|_|    |_|  \_\______|_|  |_|______|





#####################################################################





JOBFILETARGET="fiobench.job"
OUTPUTFILETARGET=$1
OUTPUTFILETARGET2=$2


usage ()
{
echo "Please assign an output file name."
echo "Example: ./fiofull.sh benchoutput.txt stressoutput.txt"
exit
}


if [ "$#" -ne 2 ]
then
    usage
fi







echo "" > "${JOBFILETARGET}"

JOBFILEHEADER="[global] ioengine=libaio runtime=120 iodepth=128 numjobs=2 time_based direct=1"

for x in $JOBFILEHEADER; do
        echo "$x" >> "${JOBFILETARGET}"
done

echo "" >> "${JOBFILETARGET}"

################################################ SUPREME ###############################
echo ""
echo ""
echo -e "           \e[32m███████\e[0m╗\e[32m██\e[0m╗   \e[32m██\e[0m╗\e[32m███████\e[0m╗\e[32m██\e[0m╗      \e[32m█████\e[0m╗ \e[32m██████\e[0m╗ "
echo -e "           \e[32m██\e[0m╔════╝╚\e[32m██\e[0m╗ \e[32m██\e[0m╔╝\e[32m██\e[0m╔════╝\e[32m██\e[0m║     \e[32m██\e[0m╔══\e[32m██\e[0m╗\e[32m██\e[0m╔══\e[32m██\e[0m╗"
echo -e "           \e[32m███████\e[0m╗ ╚\e[32m████\e[0m╔╝ \e[32m███████\e[0m╗\e[32m██\e[0m║     \e[32m███████\e[0m║\e[32m██████\e[0m╔╝"
echo -e "           ╚════\e[32m██\e[0m║  ╚\e[32m██\e[0m╔╝  ╚════\e[32m██\e[0m║\e[32m██\e[0m║     \e[32m██\e[0m╔══\e[32m██\e[0m║\e[32m██\e[0m╔══\e[32m██\e[0m╗"
echo -e "           \e[32m███████\e[0m║   \e[32m██\e[0m║   \e[32m███████\e[0m║\e[32m███████\e[0m╗\e[32m██\e[0m║  \e[32m██\e[0m║\e[32m██████\e[0m╔╝"
echo -e "           ╚══════╝   ╚═╝   ╚══════╝╚══════╝╚═╝  ╚═╝╚═════╝ "
echo " "
echo -e " \e[5m                         SYSLAB Supreme HDD Test.\e[25m"
echo -e "\e[32m Code in Beta Test : report errors to brianchen@supermicro.com \e[0m"
echo " "

#################################################################################################
#color correction:
# \e[32m = green
# \e[31m = red
# \e[93m = Orange
# \e[0m = white


#################################################################################################
#detect  partitions in drives and deletes it

echo -e "============================== \e[33mDrive Detection\e[0m =============================="
echo " "

get_sd1() {
    for a in `ls /dev/sd*[a-z] 2>/dev/null`; do
        [ "$(ls ${a}* | wc -l)" -gt "1" ] && echo $a
    done
}


for disk in $(get_sd1); do
 echo -e "Partition(s) found on \e[31m${disk}\e[0m, skipping drive."
done





get_nvme1() {
    for b in `ls /dev/nvme*n1 2>/dev/null`; do
        [ "$(ls ${b}* | wc -l)" -gt "1" ] && echo $b
    done    
 }

for disk in $(get_nvme1) ; do
echo -e "Partition(s) found on \e[31m${disk}\e[0m, skipping drive."
done
echo " "


get_nvme2() {
    for c in `ls /dev/nvme*n1 2>/dev/null`; do
        [ "$(ls ${c}* | wc -l)" == "1" ] && echo $c
    done    
 }


nvls=`nvme list 2>/dev/null`
if [ $? -ne 0 ]; then
echo "NVME CLI package not found, please yum install nvme-cli and restart."
exit 1
fi



for disk in $(get_nvme2) ; do
echo -e "Secure Erasing: \e[32m${disk}\e[0m."
nvme format -s 1 $disk
done
echo " "




################################################################

#HDD Read 1m 2m
counter=0

get_sd() {
    for aa in `ls /dev/sd*[a-z] 2>/dev/null`; do
        [ "$(ls ${aa}* | wc -l)" == "1" ] && echo $aa
    done
}


for disk in $(get_sd); do
        ####################################### 1m read ###########
        echo "[${disk}]" >> "${JOBFILETARGET}"
        echo "stonewall" >> "${JOBFILETARGET}"
        echo "filename=${disk}" >> "${JOBFILETARGET}"
        echo "bs=1m" >> "${JOBFILETARGET}"
        echo "rw=read" >> "${JOBFILETARGET}"
        echo "" >> "${JOBFILETARGET}"
        ####################################### 2m read ###########
        echo "[${disk}]" >> "${JOBFILETARGET}"
        echo "stonewall" >> "${JOBFILETARGET}"
        echo "filename=${disk}" >> "${JOBFILETARGET}"
        echo "bs=2m" >> "${JOBFILETARGET}"
        echo "rw=read" >> "${JOBFILETARGET}"
        echo "" >> "${JOBFILETARGET}"
        ########################### HDD 1m write ############
        echo "[${disk}]" >> "${JOBFILETARGET}"
        echo "stonewall" >> "${JOBFILETARGET}"
        echo "filename=${disk}" >> "${JOBFILETARGET}"
        echo "bs=1m" >> "${JOBFILETARGET}"
        echo "rw=write" >> "${JOBFILETARGET}"
        echo "" >> "${JOBFILETARGET}"
        ############################ HDD 2m write ##############
        echo "[${disk}]" >> "${JOBFILETARGET}"
        echo "stonewall" >> "${JOBFILETARGET}"
        echo "filename=${disk}" >> "${JOBFILETARGET}"
        echo "bs=2m" >> "${JOBFILETARGET}"
        echo "rw=write" >> "${JOBFILETARGET}"
        echo "" >> "${JOBFILETARGET}"
        let "counter=$counter+1"
done


        echo " "
        echo -e "\e[32m$counter\e[0m HDD/SSD available."
	hddcounter=$counter




################ NVME  ###################################################################


get_nvme() {
    for bb in `ls /dev/nvme*n1 2>/dev/null`; do
        [ "$(ls ${bb}* | wc -l)" == "1" ] && echo $bb
    done    
 }

for disk in $(get_nvme) ; do
        #JOBFILETARGETL="${JOBFILETARGET}_${disk}.fio"
        #OUTPUTFILETARGETL="${OUTPUTFILETARGET}_${disk}.fioperf"
        ###################nvme 1m read #######################
        echo "[${disk}]" >> "${JOBFILETARGET}"
        echo "stonewall" >> "${JOBFILETARGET}"
        TARGETNAME=`echo "${disk}" | cut -d'/' -f3`
        NUMA_TARGET=`cat /sys/block/${TARGETNAME}/device/device/numa_node`
        echo "numa_cpu_nodes=${NUMA_TARGET}" >> "${JOBFILETARGET}"
        echo "numa_mem_policy=bind:${NUMA_TARGET}" >> "${JOBFILETARGET}"
        echo "filename=${disk}" >> "${JOBFILETARGET}"
        echo "bs=1m" >> "${JOBFILETARGET}"
        echo "rw=read" >> "${JOBFILETARGET}"
        echo "numjobs=2" >> "${JOBFILETARGET}"
        echo "" >> "${JOBFILETARGET}"
        ###################nvme 2m read #######################
        echo "[${disk}]" >> "${JOBFILETARGET}"
        echo "stonewall" >> "${JOBFILETARGET}"
        TARGETNAME=`echo "${disk}" | cut -d'/' -f3`
        NUMA_TARGET=`cat /sys/block/${TARGETNAME}/device/device/numa_node`
        echo "numa_cpu_nodes=${NUMA_TARGET}" >> "${JOBFILETARGET}"
        echo "numa_mem_policy=bind:${NUMA_TARGET}" >> "${JOBFILETARGET}"
        echo "filename=${disk}" >> "${JOBFILETARGET}"
        echo "bs=2m" >> "${JOBFILETARGET}"
        echo "rw=read" >> "${JOBFILETARGET}"
        echo "numjobs=2" >> "${JOBFILETARGET}"
        echo "" >> "${JOBFILETARGET}"
        ###################nvme 1m write #######################
        echo "[${disk}]" >> "${JOBFILETARGET}"
        echo "stonewall" >> "${JOBFILETARGET}"
        TARGETNAME=`echo "${disk}" | cut -d'/' -f3`
        NUMA_TARGET=`cat /sys/block/${TARGETNAME}/device/device/numa_node`
        echo "numa_cpu_nodes=${NUMA_TARGET}" >> "${JOBFILETARGET}"
        echo "numa_mem_policy=bind:${NUMA_TARGET}" >> "${JOBFILETARGET}"
        echo "filename=${disk}" >> "${JOBFILETARGET}"
        echo "bs=1m" >> "${JOBFILETARGET}"
        echo "rw=write" >> "${JOBFILETARGET}"
        echo "numjobs=2" >> "${JOBFILETARGET}"
        echo "" >> "${JOBFILETARGET}"
        ###################nvme 2m write #######################
        echo "[${disk}]" >> "${JOBFILETARGET}"
        echo "stonewall" >> "${JOBFILETARGET}"
        TARGETNAME=`echo "${disk}" | cut -d'/' -f3`
        NUMA_TARGET=`cat /sys/block/${TARGETNAME}/device/device/numa_node`
        echo "numa_cpu_nodes=${NUMA_TARGET}" >> "${JOBFILETARGET}"
        echo "numa_mem_policy=bind:${NUMA_TARGET}" >> "${JOBFILETARGET}"
        echo "filename=${disk}" >> "${JOBFILETARGET}"
        echo "bs=2m" >> "${JOBFILETARGET}"
        echo "rw=write" >> "${JOBFILETARGET}"
        echo "numjobs=2" >> "${JOBFILETARGET}"
        echo "" >> "${JOBFILETARGET}"
       #/root/fio/fio "${JOBFILETARGET}" --output=$OUTPUTFILETARGET
        let "counter=$counter+1"

done
	nvmecounter=`expr $counter - $hddcounter`
	echo -e "\e[32m$nvmecounter\e[0m NVMe available."
    echo " "

if [ $counter -eq 0 ]; then
        echo -e "\e[31mNo drives available, bailing.\e[0m"
        exit 1
fi

############################# color correction ##################
green='tput setaf 2'
norm='tput sgr0'
############################# start fio #########################
echo -e "============================== \e[33mBenchmark Start\e[0m =============================="

let "st=$counter * 2 * 4"
echo " "
${green}
echo "Start Time     : $(date)"
echo "Completion ETA : $(date -d +${st}' minutes')"
${norm}
echo " "


arch=`uname -m`


if [ "$(uname -m | grep -i ppc | wc -l)" == "1" ]; then
     echo "Linux Arch: ${arch}"

     version=`./fioppc64le -v 2>/devnull`
     if [ $? -ne 0 ]; then
      echo "Fio (ppc64le) not found, please place it in the same directory as this script and restart."
      exit 1
     fi
echo "Running   : $version" 
echo " "
./fioppc64le "${JOBFILETARGET}" --output=$OUTPUTFILETARGET
fi


if [ "$(uname -m | grep -i x86 | wc -l)" == "1" ]; then
     echo "Linux Arch: ${arch}"
     version=`./fiox86 -v 2>/devnull`
     if [ $? -ne 0 ]; then
      echo "Fio (x86_64) not found, please place it in the same directory as this script and restart."
      exit 1
     fi
echo "Running   : $version"  
echo " "
./fiox86 "${JOBFILETARGET}" --output=$OUTPUTFILETARGET
fi
 
cat $OUTPUTFILETARGET | grep "(g=" | egrep -o '^[^:]+' >> A.txt
cat $OUTPUTFILETARGET | grep bw= | egrep -o '^[^,]+' >> B.txt

echo " "
echo " "
echo -e "\e[32mSummary:\e[0m"
paste -d "" A.txt B.txt

paste -d "" A.txt B.txt >> fiosummary.txt
rm -f A.txt
rm -f B.txt




echo " "
echo " "
echo -e "\e[32mBenchmark Finished.\e[0m"
echo -e "\e[32mCheck ${OUTPUTFILETARGET} in the fio directory for results.\e[0m"
echo -e "\e[32mCheck fiosummary.txt in the fio directory for short summary.\e[0m"
echo " "
echo -e "============================== \e[33mBenchmark End\e[0m ================================"

###############################################################




JOBFILETARGET="fiostress.job"




echo "" > "${JOBFILETARGET}"

JOBFILEHEADER="[global] ioengine=libaio runtime=43200 iodepth=32 time_based direct=1"

for x in $JOBFILEHEADER; do
        echo "$x" >> "${JOBFILETARGET}"
done

echo "" >> "${JOBFILETARGET}"
################################################ SUPREME ###############################
echo ""
echo ""
echo -e "           \e[32m███████\e[0m╗\e[32m██\e[0m╗   \e[32m██\e[0m╗\e[32m███████\e[0m╗\e[32m██\e[0m╗      \e[32m█████\e[0m╗ \e[32m██████\e[0m╗ "
echo -e "           \e[32m██\e[0m╔════╝╚\e[32m██\e[0m╗ \e[32m██\e[0m╔╝\e[32m██\e[0m╔════╝\e[32m██\e[0m║     \e[32m██\e[0m╔══\e[32m██\e[0m╗\e[32m██\e[0m╔══\e[32m██\e[0m╗"
echo -e "           \e[32m███████\e[0m╗ ╚\e[32m████\e[0m╔╝ \e[32m███████\e[0m╗\e[32m██\e[0m║     \e[32m███████\e[0m║\e[32m██████\e[0m╔╝"
echo -e "           ╚════\e[32m██\e[0m║  ╚\e[32m██\e[0m╔╝  ╚════\e[32m██\e[0m║\e[32m██\e[0m║     \e[32m██\e[0m╔══\e[32m██\e[0m║\e[32m██\e[0m╔══\e[32m██\e[0m╗"
echo -e "           \e[32m███████\e[0m║   \e[32m██\e[0m║   \e[32m███████\e[0m║\e[32m███████\e[0m╗\e[32m██\e[0m║  \e[32m██\e[0m║\e[32m██████\e[0m╔╝"
echo -e "           ╚══════╝   ╚═╝   ╚══════╝╚══════╝╚═╝  ╚═╝╚═════╝ "
echo " "
echo -e " \e[5m                         SYSLAB Supreme HDD Test.\e[25m"
echo -e "\e[32m Code in Beta Test : report errors to brianchen@supermicro.com \e[0m"
echo " "








echo -e "============================== \e[33mDrive Detection\e[0m =============================="
#detect  partitions in drives and deletes it
echo " "


get_sd1() {
    for a in `ls /dev/sd[a-z] 2>/dev/null`; do
        [ "$(ls ${a}* | wc -l)" -gt "1" ] && echo $a
    done
}


for disk in $(get_sd1); do
 echo -e "Partition(s) found on \e[31m${disk}\e[0m, skipping drive."
done





get_nvme1() {
    for b in `ls /dev/nvme*n1 2>/dev/null`; do
        [ "$(ls ${b}* | wc -l)" -gt "1" ] && echo $b
    done    
 }

for disk in $(get_nvme1) ; do
echo -e "Partition(s) found on \e[31m${disk}\e[0m, skipping drive."
done
echo " "

################# Calculation Numjobs #################################################
get_sd() {
    for aa in `ls /dev/sd[a-z] 2>/dev/null`; do
        [ "$(ls ${aa}* | wc -l)" == "1" ] && echo $aa
    done
}

hddcounter=`get_sd | wc -l `
if [ $? -ne 0 ]; then
  hddcounter=0
fi

get_nvme() {
    for bb in `ls /dev/nvme*n1 2>/dev/null`; do
        [ "$(ls ${bb}* | wc -l)" == "1" ] && echo $bb
    done    
 }

nvmecounter=`get_nvme | wc -l `
if [ $? -ne 0 ]; then
  nvmecounter=0
fi









if [[ $hddcounter -eq 0 && $nvmecounter -eq 0 ]]; then
        echo "No disks found, bailing."
        exit 1
fi

cpucount=`grep -c ^processor /proc/cpuinfo`
nvmejob=$(expr $nvmecounter \* 8)
total=$(($hddcounter+$nvmejob))
numjob=8

if [ $cpucount -lt $total ]; then
        numjob=$((($cpucount-$hddcounter)/($nvmecounter)))

fi
if [ $numjob -lt 1 ]; then
        numjob=1
fi

################# HDD/SSD #############################################################
get_sd() {
    for aa in `ls /dev/sd[a-z] 2>/dev/null`; do
        [ "$(ls ${aa}* | wc -l)" == "1" ] && echo $aa
    done
}


for disk in $(get_sd); do
        echo "[${disk}]" >> "${JOBFILETARGET}"
        echo "filename=${disk}" >> "${JOBFILETARGET}"
        echo "rw=randrw" >> "${JOBFILETARGET}"
        echo "numjobs=1" >> "${JOBFILETARGET}"
        echo "" >> "${JOBFILETARGET}"

done
        echo " "
        echo -e "\e[32m$hddcounter\e[0m HDD/SSD available."

################ NVME  ###################################################################

get_nvme() {
    for bb in `ls /dev/nvme*n1 2>/dev/null`; do
        [ "$(ls ${bb}* | wc -l)" == "1" ] && echo $bb
    done    
 }

for disk in $(get_nvme) ; do
        #JOBFILETARGETL="${JOBFILETARGET}_${disk}.fio"
        #OUTPUTFILETARGETL="${OUTPUTFILETARGET}_${disk}.fioperf"

        echo "[${disk}]" >> "${JOBFILETARGET}"

        TARGETNAME=`echo "${disk}" | cut -d'/' -f3`
        NUMA_TARGET=`cat /sys/block/${TARGETNAME}/device/device/numa_node`
        echo "numa_cpu_nodes=${NUMA_TARGET}" >> "${JOBFILETARGET}"
        echo "numa_mem_policy=bind:${NUMA_TARGET}" >> "${JOBFILETARGET}"
        echo "filename=${disk}" >> "${JOBFILETARGET}"
        echo "rw=randrw" >> "${JOBFILETARGET}"
        echo "numjobs="$numjob >> "${JOBFILETARGET}"
        echo "" >> "${JOBFILETARGET}"


done

  echo -e "\e[32m$nvmecounter\e[0m NVMe available."
  echo " "
############################# color correction ##################
green='tput setaf 2'
norm='tput sgr0'
############################# start fio #########################
echo -e "============================== \e[33mStress Start\e[0m ================================="

let "st=720"
echo " "
${green}
echo "Start Time     : $(date)"
echo "Completion ETA : $(date -d +${st}' minutes')"
${norm}
echo " "

echo "Thread Count     : " $cpucount
echo "Total Job Count  : " $total
echo "Max Nvme numjobs : " $numjob


arch=`uname -m`

if [ "$(uname -m | grep -i ppc | wc -l)" == "1" ]; then
     echo "Linux Arch: ${arch}"

     version=`./fioppc64le -v 2>/devnull`
     if [ $? -ne 0 ]; then
      echo "Fio (ppc64le) not found, please place it in the same directory as this script and restart."
      exit 1
     fi
echo "Running   : $version" 
echo " "
./fioppc64le "${JOBFILETARGET}" --output=$OUTPUTFILETARGET2
fi


if [ "$(uname -m | grep -i x86 | wc -l)" == "1" ]; then
     echo "Linux Arch: ${arch}"
     version=`./fiox86 -v 2>/devnull`
     if [ $? -ne 0 ]; then
      echo "Fio (x86_64) not found, please place it in the same directory as this script and restart."
      exit 1
     fi
echo "Running   : $version"  
echo " "
./fiox86 "${JOBFILETARGET}" --output=$OUTPUTFILETARGET2
fi
 

echo " "
echo " "
echo -e "\e[32mFull test Finished.\e[0m"
echo -e "\e[32mCheck dmesg for any drive related entries.\e[0m"
echo -e "\e[32mCheck ${OUTPUTFILETARGET} in the fio directory for results.\e[0m"
echo -e "\e[32mCheck ${OUTPUTFILETARGET2} in the fio directory for results.\e[0m"
echo " "
echo -e "============================== \e[33mStress End\e[0m ==================================="
###############################################################