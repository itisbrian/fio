# SUPREME LOCAL FIO



SUPREME FIO for LOCAL USE ONLY

<B>NOTE : This scripts in this repo exclude all drives with partitions.</b>

------------------------------------------------------------------------------------------------

Version: 1.0
Build Date: 4/23/2018

Supports: ppc64le, x86_64

------------------------------------------------------------------------------------------------

Usage: 

<br>Download the entire repo, and unzip it into the same directory.
<br>ex: wget https://github.com/itisbrian/supremelocal/raw/master/supremelocal-master-042318.zip
<br>chmod +x * , or chmod u+x _________

<br>./fiobench.sh <outputfile.txt>  - bench all available drives. 1M-2M, Read & Write.
<br>./fiostress.sh <outputfile.txt> - stress all available drives. bs4k, rand R&W .
<br>./fiofull.sh <benchoutput.txt> <stressoutput.txt> - performs bench + stress.

------------------------------------------------------------------------------------------------

Default Fio Parameters :

<br>SEQ   : NUMJOB=2, RUNTIME=120, IODEPTH=128, BS=1m,2m 
<br>RAND: NUMJOB=*, RUNTIME=12hr, IODEPTH=32, BS=4k

*numjobs calculated based on total cpu threads, max numjob=8.
