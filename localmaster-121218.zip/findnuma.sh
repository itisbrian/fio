#!/bin/bash
#############################################################
#   _______     _______ _               ____
#  / ____\ \   / / ____| |        /\   |  _ \
# | (___  \ \_/ / (___ | |       /  \  | |_) |
#  \___ \  \   / \___ \| |      / /\ \ |  _ <
#  ____) |  | |  ____) | |____ / ____ \| |_) |
# |_____/   |_| |_____/|______/_/    \_\____/


#   _____ _    _ _____  _____  ______ __  __ ______
#  / ____| |  | |  __ \|  __ \|  ____|  \/  |  ____|
# | (___ | |  | | |__) | |__) | |__  | \  / | |__
#  \___ \| |  | |  ___/|  _  /|  __| | |\/| |  __|
#  ____) | |__| | |    | | \ \| |____| |  | | |____
# |_____/ \____/|_|    |_|  \_\______|_|  |_|______|





#####################################################################
# This script gets executed on tty2
#
# As a note, we need some way to pass sigusr1 to the endlogging script for immediate shutdown
#
# This rolls out a 1M blocksize for spinning disks.  Different disk classes will require new parameters.
#
#
################################################ SUPREME ###############################
echo ""
echo ""
echo -e "           \e[32m███████\e[0m╗\e[32m██\e[0m╗   \e[32m██\e[0m╗\e[32m███████\e[0m╗\e[32m██\e[0m╗      \e[32m█████\e[0m╗ \e[32m██████\e[0m╗ "
echo -e "           \e[32m██\e[0m╔════╝╚\e[32m██\e[0m╗ \e[32m██\e[0m╔╝\e[32m██\e[0m╔════╝\e[32m██\e[0m║     \e[32m██\e[0m╔══\e[32m██\e[0m╗\e[32m██\e[0m╔══\e[32m██\e[0m╗"
echo -e "           \e[32m███████\e[0m╗ ╚\e[32m████\e[0m╔╝ \e[32m███████\e[0m╗\e[32m██\e[0m║     \e[32m███████\e[0m║\e[32m██████\e[0m╔╝"
echo -e "           ╚════\e[32m██\e[0m║  ╚\e[32m██\e[0m╔╝  ╚════\e[32m██\e[0m║\e[32m██\e[0m║     \e[32m██\e[0m╔══\e[32m██\e[0m║\e[32m██\e[0m╔══\e[32m██\e[0m╗"
echo -e "           \e[32m███████\e[0m║   \e[32m██\e[0m║   \e[32m███████\e[0m║\e[32m███████\e[0m╗\e[32m██\e[0m║  \e[32m██\e[0m║\e[32m██████\e[0m╔╝"
echo -e "           ╚══════╝   ╚═╝   ╚══════╝╚══════╝╚═╝  ╚═╝╚═════╝ "
echo " "
echo -e " \e[5m                         SYSLAB Supreme Nvme numa node.\e[25m"
echo -e "\e[32m Code in Beta Test : report errors to brianchen@supermicro.com \e[0m"
echo " "

#################################################################################################
#color correction:
# \e[32m = green
# \e[31m = red
# \e[93m = Orange
# \e[0m = white


#################################################################################################
#detect  partitions in drives and deletes it

echo -e "============================== \e[33mNvme Detection\e[0m =============================="
echo " "



get_nvme1() {
    for b in `ls /dev/nvme*n1 2>/dev/null`; do
        [ "$(ls ${b}* | wc -l)" -gt "1" ] && echo $b
    done    
 }

for disk in $(get_nvme1) ; do
echo -e "Partition(s) found on \e[31m${disk}\e[0m, skipping drive."
done
echo " "

get_nvme2() {
    for c in `ls /dev/nvme*n1 2>/dev/null`; do
        [ "$(ls ${c}* | wc -l)" == "1" ] && echo $c
    done    
 }



for x in $(get_nvme2) ; do
  TARGETNAME=`echo "${x}" | cut -d'/' -f3`
  NUMA_TARGET=`cat /sys/block/${TARGETNAME}/device/device/numa_node`
  echo "${x} -> ${NUMA_TARGET}"
#        d=`ls ${x}p* 2>/dev/null`
#        if [[ $d != "" ]]; then
#            echo $x " has partitions"
#            parted -s "$x" mklabel gpt
#            echo "Nvme wipe finished."
echo " "
   echo "Go to http://172.16.94.10/fiojobbuilder to generate a customized jobfile."

done
echo -e "============================== \e[33mEnd\e[0m =============================="

################################################################


###############################################################
